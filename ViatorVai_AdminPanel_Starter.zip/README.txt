Viator Vai Admin Panel — Starter package

এই প্যাকেজটি একটি নিরাপদ Admin Panel-এর শুরু করার ফাইল। GitHub Pages একা ডেটা সংরক্ষণ করতে পারে না, তাই Firebase Authentication, Firestore ও Storage লাগবে।

ফাইল:
- admin.html : Admin login + profile editor UI
- README.txt : setup নির্দেশিকা

সেটআপের ধাপ:
1. https://console.firebase.google.com/ এ গিয়ে একটি project তৈরি করুন।
2. Project settings → Your apps → Web app যোগ করুন এবং Firebase web config কপি করুন।
3. Authentication → Sign-in method → Email/Password চালু করুন; আপনার admin email/password দিয়ে user তৈরি করুন।
4. Firestore Database তৈরি করুন।
5. Storage চালু করুন।
6. admin.html-এ firebaseConfig এর PASTE_ placeholder-গুলো নিজের web config দিয়ে প্রতিস্থাপন করুন।
7. Firestore Rules-এ siteContent/profile document শুধু আপনার admin UID-কে লিখতে দিন। উদাহরণ (YOUR_ADMIN_UID বদলাতে হবে):

rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /siteContent/profile {
      allow read: if true;
      allow write: if request.auth != null && request.auth.uid == "YOUR_ADMIN_UID";
    }
  }
}

8. Storage Rules-এ profile folder-এর write permission শুধু আপনার UID-কে দিন। উদাহরণ (YOUR_ADMIN_UID বদলাতে হবে):

rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /profile/{userId}/{allPaths=**} {
      allow read: if true;
      allow write: if request.auth != null && request.auth.uid == "YOUR_ADMIN_UID";
    }
  }
}

9. admin.html-কে GitHub Pages repository-র root-এ আপলোড করুন।
10. Admin URL হবে https://YOUR-USERNAME.github.io/YOUR-REPO/admin.html
11. গুরুত্বপূর্ণ: মূল index.html-কে Firestore থেকে siteContent/profile ডেটা পড়ার কোড দিয়ে আলাদাভাবে যুক্ত করতে হবে। শুধু admin.html আপলোড করলেই মূল ওয়েবসাইটের প্রোফাইল স্বয়ংক্রিয়ভাবে বদলাবে না।
12. GitHub Pages-এ HTTPS ব্যবহার করুন। Firebase config public হতে পারে, কিন্তু password বা service-account key কখনো HTML ফাইলে রাখবেন না।

নিরাপত্তা:
- admin email-কে Firebase-এ তৈরি করুন, কিন্তু public sign-up page বানাবেন না।
- YOUR_ADMIN_UID অবশ্যই Firebase Authentication → Users থেকে কপি করুন।
- rules না বসিয়ে public write permission দেবেন না।
- এই starter file-এ placeholders থাকায় Firebase config না বসানো পর্যন্ত login/save কাজ করবে না.
