VIATOR VAI — Bangladesh Travel Website Prototype

Files:
- index.html: complete responsive single-page prototype

How to preview:
1. Open index.html in a modern browser with internet access.
2. The interactive OpenStreetMap uses Leaflet from a CDN and online map tiles.
3. The route form opens Google Maps Directions in a new tab.
4. District search filters the 64 district list. Click the arrow to set a route destination; double-click a district card to search it on Google Maps.

Current limitations / next steps:
- Districts are listed, but verified attraction-by-attraction guide content is not yet populated.
- The video cards are placeholders linking to the Viator Vai YouTube channel. Replace with specific video links/embeds when video URLs are selected.
- Route calculation and live traffic are provided by Google Maps after opening it; no transport timetable, fare, or route API is integrated.
- Map requires internet. Offline map download/navigation is not implemented.
- No CMS/admin panel yet; updating content currently requires editing HTML.
- Static site is ready to publish to a free static host such as GitHub Pages or Netlify; you must sign in and upload/publish it yourself. A public URL has not been created by this prototype.
- OpenStreetMap attribution is displayed. Follow the tile provider's usage policy for production traffic.


GOOGLE SEARCH / SEO NOTES
1. This is a prototype until it is published at a public HTTPS URL. Google cannot index a file that only exists on your device.
2. After publishing, open https://search.google.com/search-console/ and add the public website URL as a URL-prefix property. Verify ownership using one of the methods Google offers.
3. Use URL Inspection for the published homepage and select Request Indexing.
4. Create and submit sitemap.xml only after the final public URL is known. Replace the placeholder in sitemap.xml.example with the actual public homepage URL and save it as sitemap.xml.
5. Indexing and ranking are controlled by Google and are not guaranteed; it may take days or weeks.
6. Add real travel guides and actual video URLs before expecting strong rankings for competitive search terms.
