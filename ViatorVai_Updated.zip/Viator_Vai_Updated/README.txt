VIATOR VAI WEBSITE UPDATE

This package includes index.html with an added transport section in each district guide:
- Bangladesh Railway official e-ticket portal
- Bangladesh Railway official train schedules page
- BIWTC official vessel/coastal route schedule page
- bus schedule search links based on district and optional travel date

Important: this static GitHub Pages website does NOT fetch live transport data or book tickets. Train/bus/launch timetables and fares can change; verify them with the official operator for your travel date. Not every district has a rail or boat route.

To publish: open the repository on GitHub, upload/replace the repository-root index.html, commit changes, and wait for GitHub Pages to rebuild. No changes have been published online automatically.
